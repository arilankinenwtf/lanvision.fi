<?php defined('C5_EXECUTE') or die("Access Denied."); ?>

</div>

<script src="<?php echo $view->getThemePath()?>/js/main.js"></script>
<script src="<?php echo $view->getThemePath()?>/js/lazysizes.min.js" async></script>

<?php Loader::element('footer_required'); ?>
</body>
</html>
