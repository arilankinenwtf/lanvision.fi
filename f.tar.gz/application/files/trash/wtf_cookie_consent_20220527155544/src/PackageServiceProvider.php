<?php
namespace Concrete\Package\WtfCookieConsent\Src;

use Core;
use View;
use Page;
use Events;
use Config;
use Package;
use AssetList;
use User;
use URL;
use Concrete\Core\Foundation\Service\Provider as ServiceProvider;
use Concrete\Core\Localization\Localization;

class PackageServiceProvider extends ServiceProvider
{

    protected $pkgHandle = 'wtf_cookie_consent';

    public function register()
    {
        $singletons = array(
            'allowance' => '\Concrete\Package\Cookiesconsent\Src\CookieAllowance',
        );

        foreach ($singletons as $key => $value) {
            $this->app->singleton($this->pkgHandle . '/' . $key, $value);
        }
    }

    public function registerAssets()
    {
        $v = View::getInstance();
        $al = AssetList::getInstance();
        $pkg = Package::getByHandle($this->pkgHandle);

        $al->register(
            'javascript', 'cookieconsent', 'js/cookieconsent.js', 
            array('minify' => true, 'combine' => true), 
            $this->pkgHandle
        );
        $al->register(
            'javascript', 'cookieconsent_element', 'js/cookie_consent_element.js', 
            array('minify' => true, 'combine' => true), 
            $this->pkgHandle
        );
        $al->register(
            'css', 'cookieconsent', 'css/cookieconsent.css', 
            array('position' => 'F', 'minify' => true, 'combine' => true), 
            $this->pkgHandle
        );

    }

    public function registerEvents()
    {
        $pkg = Package::getByHandle($this->pkgHandle);

        Events::addListener('on_page_view', function ($event) use ($pkg) {

            $u = new User();
            $p = Page::getCurrentPage();
            $v = View::getInstance();

            if (!$u->isLoggedIn() && !$p->isAdminArea() && !$p->isError()) {
                $v->requireAsset('javascript', 'cookieconsent');
                $v->requireAsset('javascript', 'cookieconsent_element');
                $v->requireAsset('css', 'cookieconsent');
            }

            $ccLocale = $this->getPageLocale();
            $config = $pkg->getConfig();
            $currentDomain = $_SERVER['SERVER_NAME'];

            // Translations (until the translation problem is fixed..)
            if($ccLocale == 'fi_FI') {
                $nameText = "Nimi";
                $domainText = "Domain";
                $expirationText = "Säilytysaika";
                $closeText = "Sulje";
                $descText = "Kuvaus";
                $yearsText = " vuotta";
                $monthsText = " kk";
                $moreInfoText = "Lisätietoja";
                $sessionText = "Istunto";
                $necessaryText = "Välttämättömät evästeet";
                $analyticsText = "Tilastolliset evästeet";
                $targetingText = "Markkinointi- ja kohdistamisevästeet";
                $necessaryDesc = "Nämä evästeet ovat välttämättömiä tämän verkkosivuston asianmukaisen toiminnan kannalta. Ilman näitä evästeitä verkkosivusto ei välttämättä toimi oikein. Näihin evästeisiin ei tallenneta käyttäjää yksilöiviä tietoja.";
                $analyticsDesc = "Nämä evästeet keräävät tietoja siitä, kuinka verkkosivustoa käytetään, millä sivuilla vieraillaan ja mitä linkkejä on käytetty. Kaikki tiedot ovat anonymisoituja, eikä niitä voida käyttää tunnistamiseen. Kerättyjä tietoja käytetään tämän verkkosivuston kehittämiseen.";
                $targetingDesc = "";
                $C5Ldesc = "Teknisten tietojen tallentaminen sisäänkirjautuneelle käyttäjälle";
                $C5desc = "ConcreteCMS eväste joka tarkistaa käyttäjän sisäänkirjautumistilanteen";
                $ccDesc = "Tallentaa käyttäjän evästevalinnat";
                $gaDesc = "Sivukatseluiden laskemiseen ja tallentamiseen.";
                $gidDesc = "Käytetään tallentamaan tietoja siitä, kuinka vierailijat käyttävät verkkosivustoa.";
                $gatDesc = "Käytetään rajoittamaan pyyntöjen määrää.";
                $recaptchaText = "Google reCAPTCHA eväste, joka estää roskapostin lähettämisen verkkosivuston lomakkeissa.";
            } else {
                $nameText = "Name";
                $domainText = "Domain";
                $expirationText = "Expiration";
                $closeText = "Close";
                $descText = "Description";
                $yearsText = " year";
                $monthsText = " month";
                $moreInfoText = "More info";
                $sessionText = "Session";
                $necessaryText = "Strictly necessary cookies";
                $analyticsText = "Analytics cookies";
                $targetingText = "Advertisement and Targeting cookies";
                $necessaryDesc = "These cookies are essential for the proper functioning of this website. Without these cookies, the website would not work properly.";
                $analyticsDesc = "These cookies collect information about how you use the website, which pages you visited and which links you clicked on. All of the data is anonymized and cannot be used to identify you. Collected data is used for developing this website.";
                $targetingDesc = "";
                $C5Ldesc = "Saving technical info for logged in users.";
                $C5desc = "ConcreteCMS cookie for checking if user is logged in.";
                $ccDesc = "Save users cookie consent setting.";
                $gaDesc = "Used to store and count pageviews.";
                $gidDesc = "Used to store information of how visitors use a website.";
                $gatDesc = "Used to limit the number of requests.";
                $recaptchaText = "Google reCAPTCHA cookie to provide spam protection on website forms.";
            }

            // Analytics ID
            if($config->get('cookies.consent_gaID') || $config->get('cookies.consent_gtmGA')) {
                $GA_ID = $config->get('cookies.consent_gaID');
                $GA_cookies = '{
                    col1: "^_ga",
                    col2: ".'. $currentDomain . '",
                    col3: "2'.$yearsText.'",
                    col4: "'. $gaDesc .'",
                    is_regex: true
                },
                {
                    col1: "_gid",
                    col2: ".'. $currentDomain . '",
                    col3: "1'.$yearsText.'",
                    col4: "'. $gidDesc .'",
                },
                {
                    col1: "^_gat_UA",
                    col2: ".'. $currentDomain . '",
                    col3: "1 min",
                    col4: "'. $gatDesc .'",
                }';
            } else { $GA_ID = ""; $GA_cookies = ""; }

            // GTM ID
            if($config->get('cookies.consent_gtmID')) {
                $GTM_ID = $config->get('cookies.consent_gtmID');
            } else { $GTM_ID = ""; }

            // Facebook Pixel ID
            if($config->get('cookies.consent_fbpID') || $config->get('cookies.consent_gtmFBP')) {
                $FBP_ID = $config->get('cookies.consent_fbpID');
                $FBP_cookies = '{
                    col1: "_fbp",
                    col2: ".'. $currentDomain . '",
                    col3: "3'.$monthsText.'",
                    col4: "'.t('Used to store and track visits across websites.').'",
                    is_regex: true
                },
                {
                    col1: "fr",
                    col2: ".'. $currentDomain . '",
                    col3: "3'.$monthsText.'",
                    col4: "'.t('Used to provide ad delivery or retargeting.').'",
                }';
            } else { $FBP_ID = ""; $FBP_cookies = ""; }

            // Head scripts
            if($config->get('cookies.consent_necessaryScriptsHead')) {
                $necessaryScriptsHead = $config->get('cookies.consent_necessaryScriptsHead');
            } else { $necessaryScriptsHead = ""; }
            if($config->get('cookies.consent_analyticsScriptsHead')) {
                $analyticsScriptsHead = $config->get('cookies.consent_analyticsScriptsHead');
            } else { $analyticsScriptsHead = ""; }
            if($config->get('cookies.consent_marketingScriptsHead')) {
                $marketingScriptsHead = $config->get('cookies.consent_marketingScriptsHead');
            } else { $marketingScriptsHead = ""; }

            // Footer scripts
            if($config->get('cookies.consent_necessaryScriptsFooter')) {
                $necessaryScriptsFooter = $config->get('cookies.consent_necessaryScriptsFooter');
            } else { $necessaryScriptsFooter = ""; }
            if($config->get('cookies.consent_analyticsScriptsFooter')) {
                $analyticsScriptsFooter = $config->get('cookies.consent_analyticsScriptsFooter');
            } else { $analyticsScriptsFooter = ""; }
            if($config->get('cookies.consent_marketingScriptsFooter')) {
                $marketingScriptsFooter = $config->get('cookies.consent_marketingScriptsFooter');
            } else { $marketingScriptsFooter = ""; }  
            
            $analyticsCookies = '{  title: "'. $analyticsText .'",
                    description: "'. $analyticsDesc .'",
                    toggle: {
                        value: "analytics",
                        enabled: false,
                        readonly: false
                    },
                    cookie_table: [' . $GA_cookies . ']
                },';

            $marketingCookies = '{  title: "'. $targetingText .'",
                    description: "'. $targetingDesc .'",
                    toggle: {
                        value: "ads",
                        enabled: false,
                        readonly: false
                    },
                    cookie_table: [' . $FBP_cookies . ']
                },';

            // If locales cookie consent popup is enabled
            if ($config->get('cookies.consent_'.$ccLocale.'_enabled') === 'true'){

                if($config->get('cookies.consent_'.$ccLocale.'_message')) {
                    $message = $config->get('cookies.consent_'.$ccLocale.'_message');
                } else { $message = t('We use cookies, is that okay?'); }
                if($config->get('cookies.consent_'.$ccLocale.'_more-info-button-text')) {
                    $infoBtn = $config->get('cookies.consent_'.$ccLocale.'_more-info-button-text');
                } else { $infoBtn = ""; }
                if($config->get('cookies.consent_'.$ccLocale.'_accept-button-text')) {
                    $acceptBtn = $config->get('cookies.consent_'.$ccLocale.'_accept-button-text');
                } else { $acceptBtn = t('Okay'); }
                if($config->get('cookies.consent_'.$ccLocale.'save-button-text')) {
                    $saveBtn = $config->get('cookies.consent_'.$ccLocale.'save-button-text');
                } else { $saveBtn = t('Save'); }
                if($config->get('cookies.consent_'.$ccLocale.'_decline-button-text')) {
                    $declineBtn = $config->get('cookies.consent_'.$ccLocale.'_decline-button-text');
                } else { $declineBtn = t('No'); }
                if($config->get('cookies.consent_'.$ccLocale.'_more-info-page')) {
                    $pageID = $config->get('cookies.consent_'.$ccLocale.'_more-info-page');
                    $moreInfoPage = Page::getByID($pageID);
                    $url = $moreInfoPage->getCollectionLink();
                } else { $url = ""; }
                if($config->get('cookies.consent_'.$ccLocale.'_more-info-page-text')) {
                    $moreInfoPageText = $config->get('cookies.consent_'.$ccLocale.'_more-info-page-text');
                } else { $moreInfoPageText = ""; }
                if($config->get('cookies.consent_'.$ccLocale.'_long-description')) {
                    $longDesc = $config->get('cookies.consent_'.$ccLocale.'_long-description');
                    $longDesc = str_replace(array("\r", "\n"), '', $longDesc);
                } else { $longDesc = t('Customize cookie options here.'); }
                if($config->get('cookies.consent_'.$ccLocale.'_custom-choice-title')) {
                    $settingsTitle = $config->get('cookies.consent_'.$ccLocale.'_custom-choice-title');
                } else { $settingsTitle = t('Cookie settings'); }

                // Dialog style
                if($config->get('cookies.consent_consentDialogLayout')) {
                    $consentDialogLayout = $config->get('cookies.consent_consentDialogLayout');
                } else { $consentDialogLayout = "box"; }
                if($config->get('cookies.consent_consentDialogPosition')) {
                    $consentDialogPosition = $config->get('cookies.consent_consentDialogPosition');
                } else { $consentDialogPosition = "bottom right"; }
                if($config->get('cookies.consent_consentSettingsLayout')) {
                    $consentSettingsLayout = $config->get('cookies.consent_consentSettingsLayout');
                } else { $consentSettingsLayout = "bar"; }

                // Colors
                if($config->get('cookies.consent_bannerBg')) {
                    $bannerBg = $config->get('cookies.consent_bannerBg');
                } else { $bannerBg = "#ffffff"; }
                if($config->get('cookies.consent_bannerColor')) {
                    $bannerColor = $config->get('cookies.consent_bannerColor');
                } else { $bannerColor = "#000000"; }
                if($config->get('cookies.consent_accBtnBg')) {
                    $accBtnBg = $config->get('cookies.consent_accBtnBg');
                } else { $accBtnBg = "#ffffff"; }
                if($config->get('cookies.consent_accBtnColor')) {
                    $accBtnColor = $config->get('cookies.consent_accBtnColor');
                } else { $accBtnColor = "#000000"; }
                if($config->get('cookies.consent_declineBtnBg')) {
                    $declineBtnBg = $config->get('cookies.consent_declineBtnBg');
                } else { $declineBtnBg = "#ffffff"; }
                if($config->get('cookies.consent_declineBtnColor')) {
                    $declineBtnColor = $config->get('cookies.consent_declineBtnColor');
                } else { $declineBtnColor = "#000000"; }
                if($config->get('cookies.consent_linkColor')) {
                    $linkColor = $config->get('cookies.consent_linkColor');
                } else { $linkColor = "#000000"; }


                if($config->get('cookies.consent_revisionCount')) {
                    $ccRevision = $config->get('cookies.consent_revisionCount');
                } else { $ccRevision = 0; }

                if($infoBtn != '') {
                    $content = $message . ' <button type=\'button\' data-cc=\'c-settings\' class=\'cc-link\'>' . $infoBtn . '</button>';
                } else {
                    $content = $message;
                }

                $cookieScriptHead = '
                <script>
                    function logConsent(consent, allowedCategories) {
                        $consentData = {"consent" : consent};
                        $.ajax({
                            url: "' . View::url('/wtf_cookie_consent/log_consent') . '/' 
                                    . Core::make('token')->generate('log_user_consent') . '",
                            type: "POST",
                            data: $consentData,
                            success: function(data){
                                console.log(data);

                                if(!allowedCategories("ads") || !allowedCategories("analytics")) {
                                    deleteAllCookies();
                                }
                            },
                            error: function(xhr, status, error) {
                                console.log(error);
                            }
                        });
                    }

                    window.addEventListener("load", function(){
                        var cc = initCookieConsent();
                        cc.run({
                            revision: "' . $ccRevision . '",
                            current_lang: "' . $ccLocale . '",
                            autoclear_cookies: true,
                            cookie_expiration: 365,
                            theme_css: "' . URL::to('/packages/wtf_cookie_consent/css/cookieconsent.css') . '",
                            page_scripts: true,
                            mode: "opt-in",

                            onAccept: function (cookie) {

                            },

                            onChange: function (cookie, changed_categories) {
                                if (changed_categories.indexOf("analytics") > -1) {
                                    gtag("consent", "update", {
                                        "analytics_storage": (cc.allowedCategory("analytics")) ? "granted" : "denied"
                                    });
                                }
                                if (changed_categories.indexOf("ads") > -1) {
                                    gtag("consent", "update", {
                                        "ad_storage": (cc.allowedCategory("ads")) ? "granted" : "denied"
                                    });
                                }

                                if(cc.getUserPreferences()) {
                                    var consent = cc.getUserPreferences();
                                    logConsent(consent, cc.allowedCategory);
                                }
                            },

                            gui_options: {
                                consent_modal: {
                                    layout: "' . $consentDialogLayout . '",
                                    position: "' . $consentDialogPosition . '",
                                },
                                settings_modal: {
                                    layout: "' . $consentSettingsLayout . '",
                                    transition: "slide"
                                }
                            },

                            languages: {
                                "' . $ccLocale . '": {
                                    consent_modal: {
                                        revision_message: "<br> '. t('Sorry to bother you again, but there has been some changes to our terms or cookies!') .'",
                                        description: "' . $content . '<br><a href=\"'. $url .'\" class=\'cc-link\' target=\'_blank\'>'. $moreInfoPageText .'</a>' .'",
                                        primary_btn: {
                                            text: "' . $acceptBtn . '",
                                            role: "accept_all"
                                        },
                                        secondary_btn: {
                                            text: "'. $declineBtn .'",
                                            role: "accept_necessary"
                                        },
                                    },
                                    settings_modal: {
                                        title: "'. $settingsTitle .'",
                                        save_settings_btn: "'. $saveBtn .'",
                                        accept_all_btn: "'. $acceptBtn .'",
                                        reject_all_btn: "'. $declineBtn .'",
                                        close_btn_label: "'. $closeText .'",
                                        cookie_table_headers: [
                                            {col1: "'.$nameText.'"},
                                            {col2: "'.$domainText.'"},
                                            {col3: "'.$expirationText.'"},
                                            {col4: "'.$descText.'"}
                                        ],
                                        blocks: [
                                            {
                                                description: "' . $message . '"
                                            }, 
                                            {
                                                title: "'. $necessaryText .'",
                                                description: "'. $necessaryDesc .'",
                                                toggle: {
                                                    value: "necessary",
                                                    enabled: true,
                                                    readonly: true
                                                },
                                                cookie_table: [
                                                    {
                                                        col1: "CONCRETE5_LOGIN",
                                                        col2: ".'. $currentDomain . '",
                                                        col3: "'. $sessionText .'",
                                                        col4: "'. $C5Ldesc.'",
                                                        is_regex: true
                                                    },
                                                    {
                                                        col1: "CONCRETE5",
                                                        col2: ".'. $currentDomain . '",
                                                        col3: "'. $sessionText .'",
                                                        col4: "'. $C5desc .'",
                                                    },
                                                    {
                                                        col1: "cc_cookie",
                                                        col2: ".'. $currentDomain . '",
                                                        col3: "1'. $yearsText .'",
                                                        col4: "'. $ccDesc .'",
                                                    },
                                                    {
                                                        col1: "_GRECAPTCHA",
                                                        col2: ".'. $currentDomain . '",
                                                        col3: "6'. $monthsText .'",
                                                        col4: "'. $recaptchaText .'",
                                                    }
                                                ]
                                            }, 
                                            '. $analyticsCookies . '
                                            '. $marketingCookies . '
                                            {
                                                title: "'. $moreInfoText .'",
                                                description: "'. $longDesc .'<br><a href=\"'. $url .'\" class=\'cc-link\' target=\'_blank\'>'. $moreInfoPageText .'</a>' .'",
                                            }
                                        ]
                                    }
                                }
                            }
                        });
                    });
                </script>
                ';
            }

            // Add color styles to head
            $cssStyles = '';
            $cssStyles .= '
            <style>
            :root {
                --cc-btn-secondary-bg: ' . $bannerBg . ' !important;
                --cc-btn-secondary-text: ' . $bannerColor . ' !important;
            }
            .p { color: ' . $bannerColor . ' !important; }
            .desc.b-acc .p, .desc.b-acc table { color: ' . $bannerColor . ' !important; }
            .desc.b-acc,
            .desc.b-acc thead tr {
                background-color:  ' . $bannerBg . ' !important;
                border-color: ' . $accBtnColor . ' !important;
            }
            .desc.b-acc td,
            .desc.b-acc td:before {
                color: ' . $bannerColor . ' !important;
                padding: 0 !important;
                position: static !important;
            }
            .desc.b-acc td { margin-bottom: 5px; }
            .desc.b-acc td:before { margin-right: 5px; }
            #cm, #s-inr, #s-bns, #s-hdr {
                background-color: ' . $bannerBg . ' !important;
                color: ' . $bannerColor . ' !important;
            }
            #c-p-bn, #s-all-bn, #s-inr button.b-tl {
                background-color: ' . $accBtnBg . ' !important;
                color: ' . $accBtnColor . ' !important;
            }
            #s-inr button.b-tl:before { border-color:  ' . $accBtnColor . ' !important; }
            #c-s-bn, #s-rall-bn, #s-sv-bn {
                background-color: ' . $declineBtnBg . ' !important;
                color: ' . $declineBtnColor . ' !important;
            }
            .cc-link {
                border-color: ' . $linkColor . ' !important;
                color: ' . $linkColor . ' !important;
            }
            </style>';

            // Add necessary scripts to head/footer

            // Add Google analytics
            $scriptsHeadTag = '';
            $scriptsHeadTag .= $GA_ID ? '
            <script type="text/plain" data-cookiecategory="analytics" async src="https://www.googletagmanager.com/gtag/js?id=' . $GA_ID . '"></script>
            <script type="text/plain" data-cookiecategory="analytics">
                window.dataLayer = window.dataLayer || [];
                function gtag(){window.dataLayer.push(arguments);}
                gtag("js", new Date());
                gtag("config", "' . $GA_ID . '");
            </script>' : '';

            // Add Google Tag Manager
            $scriptsHeadTag .= $GTM_ID ? '
                <script>
                    // Define dataLayer and the gtag function.
                    window.dataLayer = window.dataLayer || [];
                    function gtag(){dataLayer.push(arguments);}

                    // Default ad_storage to denied.
                    gtag("consent", "default", {
                        "ad_storage": "denied",
                        "analytics_storage": "denied"
                    });
                </script>
                
                <!-- Google Tag Manager -->
                <script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({"gtm.start":
                new Date().getTime(),event:"gtm.js"});var f=d.getElementsByTagName(s)[0],
                j=d.createElement(s),dl=l!="dataLayer"?"&l="+l:"";j.async=true;j.src=
                "https://www.googletagmanager.com/gtm.js?id="+i+dl;f.parentNode.insertBefore(j,f);
                })(window,document,"script","dataLayer","' . $GTM_ID . '");</script>
                <!-- end Google Tag Manager -->

                <!--- enable analytics when "analytics" category is selected --->
                <script type="text/plain" data-cookiecategory="analytics">
                    gtag("consent", "update", {
                        "analytics_storage": "granted"
                    });
                </script>

                <!--- enable ads when "ads" category is selected --->
                <script type="text/plain" data-cookiecategory="ads">
                    gtag("consent", "update", {
                        "ad_storage": "granted"
                    });
                </script>' 
            : ''; // set empty if GTM not defined

            // Add FB Pixel
            $scriptsHeadTag .= $FBP_ID ? '
            <script type="text/plain" data-cookiecategory="ads">
            !function(f,b,e,v,n,t,s)
            {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
            n.callMethod.apply(n,arguments):n.queue.push(arguments)};
            if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version="2.0";
            n.queue=[];t=b.createElement(e);t.async=!0;
            t.src=v;s=b.getElementsByTagName(e)[0];
            s.parentNode.insertBefore(t,s)}(window,document,"script",
            "https://connect.facebook.net/en_US/fbevents.js");
            fbq("init", "'. $FBP_ID .'"); 
            fbq("track", "PageView");
            </script>' : '';

            // Add necessary tags
            $scriptsHeadTag .= $necessaryScriptsHead ? '
            <script type="text/plain" data-cookiecategory="necessary">'. $necessaryScriptsHead .'</script>' : '';

            // Add other analytics tags
            $scriptsHeadTag .= $analyticsScriptsHead ? '
            <script type="text/plain" data-cookiecategory="analytics">'. $analyticsScriptsHead .'</script>' : '';

            // Add other analytics tags
            $scriptsHeadTag .= $marketingScriptsHead ? '
            <script type="text/plain" data-cookiecategory="ads">'. $marketingScriptsHead .'</script>' : '';

            $scriptsFooterTag = '';
            // Add necessary tags footer
            $scriptsFooterTag .= $necessaryScriptsFooter ? '
            <script type="text/plain" data-cookiecategory="necessary">'. $necessaryScriptsFooter .'</script>' : '';

            // Add other analytics tags footer
            $scriptsFooterTag .= $analyticsScriptsFooter ? '
            <script type="text/plain" data-cookiecategory="analytics">'. $analyticsScriptsFooter .'</script>' : '';

            // Add other analytics tags footer
            $scriptsFooterTag .= $marketingScriptsFooter ? '
            <script type="text/plain" data-cookiecategory="ads">'. $marketingScriptsFooter .'</script>' : '';
        

            if (!$u->isLoggedIn() && !$p->isAdminArea() && !$p->isError()) {
                if($scriptsHeadTag) { $v->addHeaderItem($scriptsHeadTag); }
                if($scriptsFooterTag) { $v->addFooterItem($scriptsFooterTag); }
                if($cookieScriptHead) { $v->addHeaderItem($cookieScriptHead); }
                if($cssStyles) { $v->addHeaderItem($cssStyles); }
                $v->addFooterItem('<button type="button" class="cc-floating-btn" aria-label="' . t('Open cookie Settings') . '" data-cc="c-settings"></button>');
            }
        });
    }

    public function getPageLocale()
    {
        $id = Page::getCurrentPage()->getCollectionID();
        $c = Page::getById($id); // the page 
 
        $ml = \Concrete\Core\Multilingual\Page\Section\Section::getList();
        foreach ($ml as $m) {
            $tid = $m->getTranslatedPageID($c);
            if ($tid == $id) {
                return ($m->getLocale());
            }
        }
 
        // default to finnish
        return "fi_FI";
    }

}
