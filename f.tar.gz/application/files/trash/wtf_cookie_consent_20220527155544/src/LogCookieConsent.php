<?php
namespace Concrete\Package\WtfCookieConsent\Src;

use Log;
use Core;

class LogCookieConsent {
  public function logConsent($token = false, $consent = '') {
    if(Core::make('token')->validate('log_user_consent', $token)) {

      if(file_get_contents('php://input')) {
        $postData = file_get_contents('php://input');
        parse_str($postData, $consent);
      } else {
        $postData = '';
      }

      $date = new \DateTime();

      if($_SERVER['REMOTE_ADDR']) {
        $ip = $_SERVER['REMOTE_ADDR'];
      } else {
        $ip = '-';
      }

      if($_SERVER['HTTP_USER_AGENT']) {
        $browser = $_SERVER['HTTP_USER_AGENT'];
      } else {
        $browser = '-';
      }

      Log::addInfo( 'COOKIE CONSENT INFO __ IP: ' . $ip . ' - Browser: ' . $browser
                    . ' - Cookie consent type: ' . $consent["consent"]["accept_type"]
                    . ', accepted categories: ' . implode("/", $consent["consent"]["accepted_categories"])
                    . ' - Timestamp: ' . $date->getTimestamp());
    
      echo "Consent logged";
      exit;
    }
  }
}
?>