# wtf_cookie_consent
- Evästesuostumus lisäosa ConcreteCMS:ään
- Toimii Concretessa sekä 8- että 9-versioissa
- https://github.com/orestbida/cookieconsent 


## Toiminnallisuudet:
- Hyväksy/hylkää painikkeet
- Lisäasetukset (oletuksena analytiikalle ja markkinoinnille evästeselosteet)
- Mahdollisuus kustomoida evästeboksin värejä ja tekstejä Concreten asetuksissa
- Tekstien lisääminen kaikille kieliversioille
- Mahdollisuus lisätä Google Analytics, Tag Manager ja Facebook Pixel ID:llä
- Käyttäjän valinnan loggaus Concreten lokiin (IP-osoite, selaintiedot ja aikaleima)
- Google Tag Manager ja evästekategoriat/-suostumus: 
  - Googlen ohje GTM: https://support.google.com/tagmanager/answer/10718549?hl=fi#consent-initialization-trigger 
  - cookie consent kirjaston issue asiasta: https://github.com/orestbida/cookieconsent/issues/110 
  - "suostumustila": https://support.google.com/analytics/answer/9976101?hl=fi
  - https://developers.google.com/tag-platform/devguides/consent#tag-manager_1

## TO-DO/HUOM:
- Täytyy vielä tarkistella miten evästeiden poistaminen toimii erilaisten evästeiden kohdalla, jos käyttäjä hyväksymisen jälkeen vaihtaakin suostumuksensa hylätyksi
- Hox, jos lisää Facebook Pixelin Tag Managerin kautta, täytyy itse lisätä triggeri toisin kuin Googlen tageihin: https://github.com/orestbida/cookieconsent/issues/110#issuecomment-986722547 