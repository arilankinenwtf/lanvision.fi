<?php defined('C5_EXECUTE') or die(_("Access Denied.")) ?>

<div class="empty-spacer-desktop empty-spacer-<?php echo $heightDesktop; ?>" aria-hidden="true"></div>

<div class="empty-spacer-tablet empty-spacer-<?php echo $heightTablet; ?>" aria-hidden="true"></div>

<div class="empty-spacer-mobile empty-spacer-<?php echo $heightMobile; ?>" aria-hidden="true"></div>
